# Roll24 Asset Pack — Analog Tactile UI v0.1

Assets iniciais para uma UI tátil e analógica, mas limpa, moderna e premium. Não é velho, destruído, sujo, steampunk ou vintage caricato.

## Conteúdo
- referências visuais
- tokens JSON/CSS/Kotlin
- texturas limpas
- overlays de grão/vinheta/halation
- ícones SVG/Android Vector
- cards dos perfis de filme
- snippets Compose

## Regra visual
Tátil e analógico não significa velho. Significa intenção, controle, matéria e resposta física.
