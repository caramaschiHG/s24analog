# Guia Visual Roll24

Moderno, físico, fotográfico, preciso e silencioso.

Certo: microtextura limpa, bordas com leve highlight, botões pressionáveis, detalhes metálicos quentes.

Errado: arranhão exagerado, ferrugem, poeira fake, couro rachado, câmera antiga destruída.
