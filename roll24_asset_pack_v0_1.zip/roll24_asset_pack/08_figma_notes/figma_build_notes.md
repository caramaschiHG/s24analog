# Notas Figma

Frame 393x852 ou 430x932. Superfície #080807 + textura em 8–14%. Painel com radius 22px e stroke #34312B. Botão com estado pressionado scale 0.92.
